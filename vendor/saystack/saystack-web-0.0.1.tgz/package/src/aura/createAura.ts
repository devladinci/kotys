import type { AuraLayout, AuraPlacement, IAuraStyle } from "@saystack/core";
import { bandPalette, resolveAuraStyle } from "@saystack/core";

import { FRAGMENT_SHADER, MAX_BANDS, VERTEX_SHADER } from "./shaders.js";

export type AuraState = "hidden" | "active" | "working" | "paused";

export type AuraMode = "auto" | "dark" | "light";

export interface IAuraOptions {
  anchor?: Element | null;
  levels?: () => ArrayLike<number> | undefined;
  style?: Partial<IAuraStyle>;
  padding?: number;
  radius?: number;
  gap?: number;
  isInside?: boolean;
  clip?: Element | null;
  mode?: AuraMode;
  glideMs?: number;
  zIndex?: number;
  pageRadius?: number;
}

export interface IAuraAnchorOptions {
  isGliding?: boolean;
}

export interface IAura {
  readonly canvas: HTMLCanvasElement;
  readonly state: AuraState;
  setState(next: AuraState): void;
  setAnchor(anchor: Element | null, options?: IAuraAnchorOptions): void;
  update(options: Omit<IAuraOptions, "anchor">): void;
  destroy(): void;
}

interface ISettings {
  levels: (() => ArrayLike<number> | undefined) | null;
  style: IAuraStyle;
  padding: number;
  radius: number | null;
  gap: number;
  isInside: boolean;
  clip: Element | null;
  mode: AuraMode;
  glideMs: number;
  zIndex: number;
  pageRadius: number;
}

interface IRect {
  x: number;
  y: number;
  w: number;
  h: number;
  r: number;
  isPage: boolean;
  isInner: boolean;
}

interface ISpectrum {
  center: number;
  span: number;
  dir: number;
}

type Uniforms = Record<(typeof UNIFORMS)[number], WebGLUniformLocation | null>;

const UNIFORMS = [
  "u_px",
  "u_size",
  "u_center",
  "u_half",
  "u_radius",
  "u_pradius",
  "u_inner",
  "u_time",
  "u_count",
  "u_band",
  "u_band2",
  "u_colors",
  "u_mix",
  "u_height",
  "u_line",
  "u_gap",
  "u_glow",
  "u_gain",
  "u_emph",
  "u_vis",
  "u_orbit",
  "u_lightMode",
  "u_layout",
  "u_specCenter",
  "u_span",
  "u_dir",
  "u_pxSize",
  "u_aura",
] as const;

const STATE_TARGETS: Readonly<Record<AuraState, readonly [number, number, number]>> = {
  hidden: [0, 0, 0],
  active: [1, 1, 0],
  working: [1, 0, 1],
  paused: [0.7, 0, 0],
};

const EMPHASIS: Readonly<Record<AuraPlacement, readonly [number, number, number]>> = {
  top: [1, 0.3, 0.05],
  around: [1, 1, 1],
  bottom: [0.05, 0.3, 1],
};

const LAYOUT_INDEX: Readonly<Record<AuraLayout, number>> = { mirror: 0, linear: 1, flow: 2 };

const PAGE_LIFT = 1.7;

const PAGE_GLOW = 1.6;

const ECHO_MS = 80;

const HISTORY_FRAMES = 32;

let colorProbe: CanvasRenderingContext2D | null | undefined;

const luminanceOf = (color: string): number | null => {
  if (colorProbe === undefined) {
    colorProbe = document.createElement("canvas").getContext("2d", { willReadFrequently: true });
  }

  if (colorProbe === null) {
    return null;
  }

  colorProbe.clearRect(0, 0, 1, 1);
  colorProbe.fillStyle = color;
  colorProbe.fillRect(0, 0, 1, 1);
  const [red = 0, green = 0, blue = 0, alpha = 0] = colorProbe.getImageData(0, 0, 1, 1).data;

  return alpha < 128 ? null : (0.2126 * red + 0.7152 * green + 0.0722 * blue) / 255;
};

const approach = (value: number, target: number, dt: number, tau: number): number =>
  value + (target - value) * (1 - Math.exp(-dt / tau));

const lerp = (a: number, b: number, k: number): number => a + (b - a) * k;

function resolveSettings(options: IAuraOptions, previous?: ISettings): ISettings {
  const base = previous ?? {
    levels: null,
    style: resolveAuraStyle(),
    padding: 0,
    radius: null,
    gap: 1.5,
    isInside: false,
    clip: null,
    mode: "auto",
    glideMs: 480,
    zIndex: 2147483000,
    pageRadius: 0,
  };

  return {
    levels: options.levels ?? base.levels,
    style: options.style === undefined ? base.style : resolveAuraStyle({ ...base.style, ...options.style }),
    padding: options.padding ?? base.padding,
    radius: options.radius ?? base.radius,
    gap: options.gap ?? base.gap,
    isInside: options.isInside ?? base.isInside,
    clip: options.clip === undefined ? base.clip : options.clip,
    mode: options.mode ?? base.mode,
    glideMs: options.glideMs ?? base.glideMs,
    zIndex: options.zIndex ?? base.zIndex,
    pageRadius: options.pageRadius ?? base.pageRadius,
  };
}

function compile(gl: WebGLRenderingContext, type: number, source: string): WebGLShader {
  const shader = gl.createShader(type);

  if (shader === null) {
    throw new Error("aura: could not create a shader");
  }

  gl.shaderSource(shader, source);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    throw new Error(`aura: ${gl.getShaderInfoLog(shader) ?? "shader did not compile"}`);
  }

  return shader;
}

function link(gl: WebGLRenderingContext): Uniforms {
  const program = gl.createProgram();

  if (program === null) {
    throw new Error("aura: could not create a program");
  }

  gl.attachShader(program, compile(gl, gl.VERTEX_SHADER, VERTEX_SHADER));
  gl.attachShader(program, compile(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER));
  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw new Error(`aura: ${gl.getProgramInfoLog(program) ?? "program did not link"}`);
  }

  gl.useProgram(program);
  gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const position = gl.getAttribLocation(program, "a_pos");
  gl.enableVertexAttribArray(position);
  gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);

  return Object.fromEntries(UNIFORMS.map((name) => [name, gl.getUniformLocation(program, name)])) as Uniforms;
}

function inertAura(canvas: HTMLCanvasElement, initial: AuraState): IAura {
  let state = initial;

  return {
    canvas,
    get state() {
      return state;
    },
    setState(next) {
      state = next;
    },
    setAnchor: () => undefined,
    update: () => undefined,
    destroy: () => undefined,
  };
}

export function createAura(options: IAuraOptions = {}): IAura {
  let settings = resolveSettings(options);
  let anchor = options.anchor ?? null;
  const canvas = document.createElement("canvas");
  canvas.className = "saystack-aura";
  canvas.setAttribute("aria-hidden", "true");
  canvas.style.position = "fixed";
  canvas.style.left = "0";
  canvas.style.top = "0";
  canvas.style.pointerEvents = "none";
  canvas.style.display = "none";
  canvas.style.zIndex = String(settings.zIndex);

  if (typeof WebGLRenderingContext === "undefined") {
    return inertAura(canvas, "hidden");
  }

  const gl = canvas.getContext("webgl", {
    alpha: true,
    premultipliedAlpha: true,
    antialias: false,
    depth: false,
    stencil: false,
    powerPreference: "low-power",
  });

  if (gl === null) {
    return inertAura(canvas, "hidden");
  }

  let uniforms: Uniforms;

  try {
    uniforms = link(gl);
  } catch {
    return inertAura(canvas, "hidden");
  }

  document.body.append(canvas);

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const bands = new Float32Array(MAX_BANDS * 4);
  const echoBands = new Float32Array(MAX_BANDS * 4);
  const colorsOnDark = new Float32Array(MAX_BANDS * 3);
  const colorsOnLight = new Float32Array(MAX_BANDS * 3);
  const phases = new Float32Array(MAX_BANDS);
  const echoPhases = new Float32Array(MAX_BANDS);
  const current = new Float32Array(MAX_BANDS);
  const cycles = new Float32Array(MAX_BANDS).fill(1);
  const previousCycles = new Float32Array(MAX_BANDS).fill(1);
  const history = Array.from({ length: HISTORY_FRAMES }, () => ({ at: -Infinity, levels: new Float32Array(MAX_BANDS) }));
  let historyIndex = 0;
  let cyclePerimeter = 0;
  let cycleMix = 1;
  let cycleMixStart = 0;
  let isCycleStale = false;

  let state: AuraState = "hidden";
  let visibility = 0;
  let activity = 0;
  let orbit = 0;
  let time = Math.random() * 100;
  let frame = 0;
  let lastFrame = 0;
  let lastRect: IRect | null = null;
  let glideFrom: IRect | null = null;
  let glideStart = 0;
  let mode: "dark" | "light" | null = null;
  let modeCheckedAt = -Infinity;
  let radii = new WeakMap<Element, number>();
  let boxWidth = 0;
  let boxHeight = 0;
  let clipPath = "";
  let isLost = false;

  const rebuildPalette = (): void => {
    const palette = bandPalette(settings.style.palette, settings.style.bands);
    colorsOnDark.fill(0);
    colorsOnLight.fill(0);
    palette.onDark.forEach((color, index) => colorsOnDark.set(color, index * 3));
    palette.onLight.forEach((color, index) => colorsOnLight.set(color, index * 3));
  };

  rebuildPalette();

  const handleContextLost = (event: Event): void => {
    event.preventDefault();
    isLost = true;
  };

  const handleContextRestored = (): void => {
    uniforms = link(gl);
    isLost = false;
  };

  canvas.addEventListener("webglcontextlost", handleContextLost);
  canvas.addEventListener("webglcontextrestored", handleContextRestored);

  const radiusOf = (element: Element, box: DOMRect): number => {
    if (settings.radius !== null) {
      return settings.radius;
    }

    const cached = radii.get(element);

    if (cached !== undefined) {
      return cached;
    }

    const value = getComputedStyle(element).borderTopLeftRadius;
    const radius = value.endsWith("%")
      ? (parseFloat(value) / 100) * Math.min(box.width, box.height)
      : parseFloat(value) || 0;
    radii.set(element, radius);

    return radius;
  };

  const measure = (element: Element | null): IRect => {
    const root = document.documentElement;

    if (element === null) {
      return { x: 0, y: 0, w: root.clientWidth, h: root.clientHeight, r: settings.pageRadius, isPage: true, isInner: true };
    }

    const box = element.getBoundingClientRect();
    const pad = settings.padding;
    const w = box.width + pad * 2;
    const h = box.height + pad * 2;
    const r = Math.max(0, Math.min(radiusOf(element, box) + pad, w / 2, h / 2));

    return { x: box.left - pad, y: box.top - pad, w, h, r, isPage: false, isInner: settings.isInside };
  };

  const currentRect = (now: number): IRect => {
    const target = measure(anchor);

    if (glideFrom === null || reducedMotion.matches) {
      return target;
    }

    const progress = Math.min(1, (now - glideStart) / settings.glideMs);

    if (progress >= 1 || glideFrom.isInner !== target.isInner) {
      glideFrom = null;
      return target;
    }

    const eased = 1 - (1 - progress) ** 3;

    return {
      x: lerp(glideFrom.x, target.x, eased),
      y: lerp(glideFrom.y, target.y, eased),
      w: lerp(glideFrom.w, target.w, eased),
      h: lerp(glideFrom.h, target.h, eased),
      r: lerp(glideFrom.r, target.r, eased),
      isPage: target.isPage,
      isInner: target.isInner,
    };
  };

  const liftOf = (rect: IRect): number => settings.style.lift * (rect.isPage ? PAGE_LIFT : 1);

  const glowOf = (rect: IRect): number => settings.style.auraSize * (rect.isPage ? PAGE_GLOW : 1);

  const reachOf = (rect: IRect): number => settings.gap + settings.style.lineWidth + liftOf(rect) * 1.3 + glowOf(rect) * 4 + 2;

  const perimeterOf = (rect: IRect, radius: number): number =>
    2 * Math.max(0, rect.w - 2 * radius) + 2 * Math.max(0, rect.h - 2 * radius) + 2 * Math.PI * radius;

  // Flow waves need a whole number of cycles around the outline to stay seamless.
  const updateCycles = (rect: IRect, perimeter: number, now: number): void => {
    const hasChanged = cyclePerimeter === 0 || Math.abs(perimeter - cyclePerimeter) / cyclePerimeter > 0.3;

    if (isCycleStale || hasChanged) {
      previousCycles.set(cycles);
      const scale = rect.isPage ? 1.8 : 1;

      for (let index = 0; index < MAX_BANDS; index += 1) {
        const share = settings.style.bands > 1 ? index / (settings.style.bands - 1) : 0;
        cycles[index] = Math.max(1, Math.round(perimeter / (380 * (70 / 380) ** share * scale)));
      }

      cycleMix = cyclePerimeter === 0 ? 1 : 0;
      cycleMixStart = now;
      cyclePerimeter = perimeter;
      isCycleStale = false;
    }

    cycleMix = Math.min(1, (now - cycleMixStart) / 450);
  };

  const spectrumOf = (rect: IRect, radius: number, perimeter: number): ISpectrum => {
    if (settings.style.placement === "around") {
      return { center: 0, span: 0.5, dir: 1 };
    }

    const edge = Math.max(0, rect.w / 2 - radius) + (Math.PI / 2) * radius * 0.6;
    const span = Math.min(0.5, Math.max(0.02, edge / perimeter));

    return settings.style.placement === "bottom" ? { center: 0.5, span, dir: -1 } : { center: 0, span, dir: 1 };
  };

  const detectMode = (): "dark" | "light" => {
    if (settings.mode !== "auto") {
      return settings.mode;
    }

    const probe = anchor?.isConnected === true ? anchor : document.documentElement;
    const declared = getComputedStyle(probe).getPropertyValue("--saystack-aura-mode").trim();

    if (declared === "light" || declared === "dark") {
      return declared;
    }

    for (let element: Element | null = probe; element !== null; element = element.parentElement) {
      const luminance = luminanceOf(getComputedStyle(element).backgroundColor);

      if (luminance !== null) {
        return luminance > 0.5 ? "light" : "dark";
      }
    }

    const scheme = getComputedStyle(document.documentElement).colorScheme;

    if (scheme === "light" || scheme === "dark") {
      return scheme;
    }

    return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  };

  const hide = (): void => {
    canvas.style.display = "none";
  };

  const recordLevels = (now: number, dt: number, motion: number): void => {
    const source = settings.levels?.();
    const speed = settings.style.rippleSpeed * motion;

    for (let index = 0; index < MAX_BANDS; index += 1) {
      const level = source !== undefined && index < settings.style.bands ? (source[index] ?? 0) * activity : 0;
      phases[index] = (phases[index] ?? 0) + dt * speed * (0.15 + 3.2 * level) * (index % 2 === 1 ? -1 : 1) * (1 + index * 0.25);
      bands[index * 4] = level;
      bands[index * 4 + 1] = phases[index] ?? 0;
      current[index] = level;
    }

    const slot = history[historyIndex];

    if (slot !== undefined) {
      slot.at = now;
      slot.levels.set(current);
    }

    historyIndex = (historyIndex + 1) % HISTORY_FRAMES;

    let echo = current;
    let echoAt = -Infinity;

    for (const entry of history) {
      if (entry.at <= now - ECHO_MS && entry.at > echoAt) {
        echo = entry.levels;
        echoAt = entry.at;
      }
    }

    for (let index = 0; index < MAX_BANDS; index += 1) {
      const level = echo[index] ?? 0;
      echoPhases[index] = (echoPhases[index] ?? 0) + dt * speed * (0.15 + 3.2 * level) * (index % 2 === 1 ? 1 : -1) * (1.1 + index * 0.2);
      echoBands[index * 4] = level;
      echoBands[index * 4 + 1] = echoPhases[index] ?? 0;
    }
  };

  const loudness = (): number => {
    let sum = 0;

    for (let index = 0; index < settings.style.bands; index += 1) {
      sum += current[index] ?? 0;
    }

    return sum / Math.max(1, settings.style.bands);
  };

  const draw = (rect: IRect, radius: number, perimeter: number, breathe: number): void => {
    const root = document.documentElement;
    const viewportWidth = root.clientWidth;
    const viewportHeight = root.clientHeight;
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    const scale = pixelRatio * settings.style.resolution * (rect.isPage ? 0.75 : 1);
    let boxX = 0;
    let boxY = 0;
    let width = viewportWidth;
    let height = viewportHeight;

    if (rect.isInner && !rect.isPage) {
      const x0 = Math.max(0, Math.floor(rect.x));
      const y0 = Math.max(0, Math.floor(rect.y));
      const x1 = Math.min(viewportWidth, Math.ceil(rect.x + rect.w));
      const y1 = Math.min(viewportHeight, Math.ceil(rect.y + rect.h));

      if (x1 <= x0 || y1 <= y0) {
        hide();
        return;
      }

      boxX = x0;
      boxY = y0;
      width = x1 - x0;
      height = y1 - y0;
    } else if (!rect.isInner) {
      const margin = Math.ceil(reachOf(rect) + 2);
      const x0 = Math.max(-4, Math.floor(rect.x - margin));
      const y0 = Math.max(-4, Math.floor(rect.y - margin));
      const x1 = Math.min(viewportWidth + 4, Math.ceil(rect.x + rect.w + margin));
      const y1 = Math.min(viewportHeight + 4, Math.ceil(rect.y + rect.h + margin));

      if (x1 <= x0 || y1 <= y0) {
        hide();
        return;
      }

      boxX = x0;
      boxY = y0;
      width = Math.ceil((x1 - x0) / 32) * 32;
      height = Math.ceil((y1 - y0) / 32) * 32;
    }

    let nextClip = "none";

    if (settings.clip !== null) {
      const limit = settings.clip.getBoundingClientRect();
      const top = Math.max(0, Math.round(limit.top - boxY));
      const left = Math.max(0, Math.round(limit.left - boxX));
      const right = Math.max(0, Math.round(boxX + width - limit.right));
      const bottom = Math.max(0, Math.round(boxY + height - limit.bottom));

      if (top + bottom >= height || left + right >= width) {
        hide();
        return;
      }

      nextClip = `inset(${top}px ${right}px ${bottom}px ${left}px)`;
    }

    if (nextClip !== clipPath) {
      canvas.style.clipPath = nextClip;
      clipPath = nextClip;
    }

    canvas.style.display = "block";
    const pixelWidth = Math.max(1, Math.round(width * scale));
    const pixelHeight = Math.max(1, Math.round(height * scale));

    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }

    if (width !== boxWidth || height !== boxHeight) {
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      boxWidth = width;
      boxHeight = height;
    }

    canvas.style.transform = `translate(${boxX}px, ${boxY}px)`;

    const emphasis = settings.style.outline === "full" ? EMPHASIS.around : EMPHASIS[settings.style.placement];
    const spectrum = spectrumOf(rect, radius, perimeter);

    gl.viewport(0, 0, pixelWidth, pixelHeight);
    gl.uniform2f(uniforms.u_px, pixelWidth, pixelHeight);
    gl.uniform2f(uniforms.u_size, width, height);
    gl.uniform2f(uniforms.u_center, rect.x + rect.w / 2 - boxX, rect.y + rect.h / 2 - boxY);
    gl.uniform2f(uniforms.u_half, rect.w / 2, rect.h / 2);
    gl.uniform1f(uniforms.u_radius, rect.r);
    gl.uniform1f(uniforms.u_pradius, radius);
    gl.uniform1f(uniforms.u_inner, rect.isInner ? 1 : 0);
    gl.uniform1f(uniforms.u_time, time);
    gl.uniform1f(uniforms.u_count, settings.style.bands);
    gl.uniform4fv(uniforms.u_band, bands);
    gl.uniform4fv(uniforms.u_band2, echoBands);
    gl.uniform3fv(uniforms.u_colors, mode === "light" ? colorsOnLight : colorsOnDark);
    gl.uniform1f(uniforms.u_mix, cycleMix);
    gl.uniform1f(uniforms.u_height, liftOf(rect));
    gl.uniform1f(uniforms.u_line, settings.style.lineWidth);
    gl.uniform1f(uniforms.u_gap, settings.gap);
    gl.uniform1f(uniforms.u_glow, Math.max(0.5, glowOf(rect)));
    gl.uniform1f(uniforms.u_gain, settings.style.brightness * breathe);
    gl.uniform3f(uniforms.u_emph, emphasis[0], emphasis[1], emphasis[2]);
    gl.uniform1f(uniforms.u_vis, visibility);
    gl.uniform1f(uniforms.u_orbit, orbit);
    gl.uniform1f(uniforms.u_lightMode, mode === "light" ? 1 : 0);
    gl.uniform1f(uniforms.u_layout, LAYOUT_INDEX[settings.style.layout]);
    gl.uniform1f(uniforms.u_specCenter, spectrum.center);
    gl.uniform1f(uniforms.u_span, spectrum.span);
    gl.uniform1f(uniforms.u_dir, spectrum.dir);
    gl.uniform1f(uniforms.u_pxSize, width / pixelWidth);
    gl.uniform1f(uniforms.u_aura, settings.style.aura);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  };

  const render = (now: number): void => {
    frame = 0;
    const dt = lastFrame === 0 ? 1 / 60 : Math.min(0.05, (now - lastFrame) / 1000);
    lastFrame = now;
    const [targetVisibility, targetActivity, targetOrbit] = STATE_TARGETS[state];
    visibility = approach(visibility, targetVisibility, dt, targetVisibility > visibility ? 0.14 : 0.24);
    activity = approach(activity, targetActivity, dt, 0.12);
    orbit = approach(orbit, targetOrbit, dt, 0.28);

    if (state === "hidden" && visibility < 0.004) {
      visibility = 0;
      lastFrame = 0;
      hide();
      return;
    }

    frame = requestAnimationFrame(render);

    if (isLost) {
      return;
    }

    const motion = reducedMotion.matches ? 0.12 : 1;
    time += dt * motion;

    if (now - modeCheckedAt > 800) {
      modeCheckedAt = now;
      const next = detectMode();

      if (next !== mode) {
        mode = next;
        canvas.style.mixBlendMode = mode === "light" ? "normal" : "plus-lighter";
      }
    }

    recordLevels(now, dt, motion);
    const quiet = 1 - Math.min(1, loudness() * 4);
    const breathe = 1 + 0.1 * Math.sin(now / 420) * quiet * activity;
    const rect = currentRect(now);
    lastRect = rect;

    if (rect.w < 1 || rect.h < 1) {
      hide();
      return;
    }

    const radius = rect.isInner ? Math.max(rect.r, reachOf(rect)) : rect.r;
    const perimeter = perimeterOf(rect, radius);
    updateCycles(rect, perimeter, now);

    for (let index = 0; index < MAX_BANDS; index += 1) {
      bands[index * 4 + 2] = cycles[index] ?? 1;
      bands[index * 4 + 3] = previousCycles[index] ?? 1;
    }

    draw(rect, radius, perimeter, breathe);
  };

  const wake = (): void => {
    if (frame === 0) {
      lastFrame = 0;
      frame = requestAnimationFrame(render);
    }
  };

  return {
    canvas,
    get state() {
      return state;
    },
    setState(next) {
      state = next;

      if (next !== "hidden") {
        wake();
      }
    },
    setAnchor(next, { isGliding = true } = {}) {
      if (next === anchor) {
        return;
      }

      glideFrom = isGliding && lastRect !== null && visibility > 0.02 && (next === null) === (anchor === null) ? lastRect : null;
      glideStart = performance.now();
      anchor = next;
      isCycleStale = true;
      modeCheckedAt = -Infinity;
    },
    update(next) {
      const previous = settings;
      settings = resolveSettings(next, settings);
      canvas.style.zIndex = String(settings.zIndex);

      if (previous.style.palette !== settings.style.palette || previous.style.bands !== settings.style.bands) {
        rebuildPalette();
      }

      if (previous.style.bands !== settings.style.bands) {
        isCycleStale = true;
      }

      if (previous.radius !== settings.radius || previous.padding !== settings.padding) {
        radii = new WeakMap();
      }

      if (previous.mode !== settings.mode) {
        modeCheckedAt = -Infinity;
      }
    },
    destroy() {
      cancelAnimationFrame(frame);
      frame = 0;
      canvas.removeEventListener("webglcontextlost", handleContextLost);
      canvas.removeEventListener("webglcontextrestored", handleContextRestored);
      canvas.remove();
      gl.getExtension("WEBGL_lose_context")?.loseContext();
    },
  };
}
