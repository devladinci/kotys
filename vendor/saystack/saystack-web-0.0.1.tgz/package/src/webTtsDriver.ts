import type { ISpeechClipResult, ITtsDriver, ITtsSynthesizeResult, TtsErrorCode } from "@saystack/core";

import { sharedAudioContext, unlockWebAudio } from "./audioContext.js";
import { createWebClip } from "./webClip.js";

export interface IWebTtsDriverOptions {
  endpoint: string;
  headers?: Readonly<Record<string, string>>;
  context?: AudioContext;
  output?: AudioNode | (() => AudioNode | null);
  fetch?: (input: string, init: RequestInit) => Promise<Response>;
}

const TTS_ERROR_CODES: readonly string[] = [
  "NO_ADAPTER",
  "EMPTY_TEXT",
  "TEXT_TOO_LONG",
  "MODEL_NOT_FOUND",
  "BAD_TOKEN",
  "TTS_UNAVAILABLE",
  "TTS_REJECTED_INPUT",
  "TTS_RETRYABLE",
  "TTS_FAILED",
  "TTS_TIMEOUT",
  "TTS_UNSUPPORTED_MEDIA",
];

const isTtsErrorCode = (value: unknown): value is TtsErrorCode =>
  typeof value === "string" && TTS_ERROR_CODES.includes(value);

async function failure(response: Response): Promise<ITtsSynthesizeResult> {
  const body = (await response.json().catch(() => null)) as { errorCode?: unknown; message?: unknown } | null;
  const errorCode = isTtsErrorCode(body?.errorCode) ? body.errorCode : "TTS_FAILED";
  const message = typeof body?.message === "string" ? body.message : `speech endpoint said ${response.status}`;

  return { ok: false, errorCode, message };
}

export function createWebTtsDriver({ endpoint, headers = {}, context, output, fetch }: IWebTtsDriverOptions): ITtsDriver {
  const audioContext = (): AudioContext => context ?? sharedAudioContext();
  const send = fetch ?? ((input: string, init: RequestInit) => globalThis.fetch(input, init));

  return {
    unlock: () => {
      unlockWebAudio(audioContext());
    },

    synthesize: async (input): Promise<ITtsSynthesizeResult> => {
      const body = {
        text: input.text,
        ...(input.refAudio !== undefined && input.refText !== undefined
          ? { refAudio: input.refAudio, refText: input.refText }
          : {}),
      };
      let response: Response;

      try {
        response = await send(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", ...headers },
          body: JSON.stringify(body),
          ...(input.signal === undefined ? {} : { signal: input.signal }),
        });
      } catch {
        if (input.signal?.aborted === true) {
          return { ok: false, errorCode: "TTS_FAILED", message: "cancelled by caller" };
        }

        return { ok: false, errorCode: "TTS_UNAVAILABLE", message: "could not reach the speech endpoint" };
      }

      if (!response.ok) {
        return failure(response);
      }

      const audio = await response.arrayBuffer().catch(() => null);

      if (audio === null || audio.byteLength === 0) {
        return { ok: false, errorCode: "TTS_FAILED", message: "the speech endpoint returned no audio" };
      }

      return { ok: true, audio, mimeType: response.headers.get("content-type") ?? "audio/wav" };
    },

    createClip: async (audio): Promise<ISpeechClipResult> => {
      const destination = typeof output === "function" ? output() : (output ?? null);

      try {
        const clip = await createWebClip(audio, {
          context: audioContext(),
          ...(destination === null ? {} : { output: destination }),
        });

        return { ok: true, clip };
      } catch (error: unknown) {
        return {
          ok: false,
          errorCode: "TTS_UNSUPPORTED_MEDIA",
          message: error instanceof Error ? error.message : "the audio could not be decoded",
        };
      }
    },
  };
}
