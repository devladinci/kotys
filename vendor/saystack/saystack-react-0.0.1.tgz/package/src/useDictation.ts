import { useRef, useState } from "react";
import type { IPlatformRecorder, SttErrorCode } from "@saystack/core";
import { getVoiceRecorder } from "@saystack/core";
import { dictationEndpoint, sendDictation } from "./dictationSender.js";
import type {
  DictationState,
  IDictationSendOptions,
  IUseDictationOptions,
  IUseDictationResult,
} from "./types.js";

export function useDictation(options: IUseDictationOptions = {}): IUseDictationResult {
  const endpoint = options.endpoint ?? dictationEndpoint(window.location.origin);
  const prompt = options.prompt;
  const onText = options.onText;

  const [state, setState] = useState<DictationState>("idle");
  const [text, setText] = useState("");
  const [errorCode, setErrorCode] = useState<SttErrorCode | undefined>(undefined);

  const recorderRef = useRef<IPlatformRecorder | undefined>(undefined);
  const busyRef = useRef(false);
  const seqRef = useRef(0);

  const finishError = (code: SttErrorCode): void => {
    setErrorCode(code);
    setState("error");
  };

  const handlePressStart = (): void => {
    if (busyRef.current) return;

    const platform = getVoiceRecorder();
    if (!platform.ok) {
      finishError(platform.errorCode);
      return;
    }

    busyRef.current = true;
    setErrorCode(undefined);
    setState("recording");
    recorderRef.current = platform.recorder;

    const seq = seqRef.current;

    void platform.recorder.startRecording().catch((error: unknown) => {
      if (seqRef.current !== seq) return;
      busyRef.current = false;
      finishError(startErrorCode(error));
    });
  };

  const handlePressEnd = (): void => {
    if (!busyRef.current) return;
    busyRef.current = false;
    seqRef.current += 1;

    const recorder = recorderRef.current;
    if (!recorder) {
      setState("idle");
      return;
    }

    setState("transcribing");

    const abort = new AbortController();
    const seq = seqRef.current;

    void recorder
      .stopRecording()
      .then((recording) => {
        const sendOptions: IDictationSendOptions = {};
        if (prompt !== undefined) sendOptions.prompt = prompt;
        sendOptions.signal = abort.signal;
        return sendDictation(endpoint, recording, sendOptions);
      })
      .then((result) => {
        if (seqRef.current !== seq) return;
        if (result.ok) {
          setText(result.text);
          setState("done");
          onText?.(result.text);
        } else {
          finishError(result.errorCode);
        }
      })
      .catch((error: unknown) => {
        if (seqRef.current !== seq) return;
        finishError(sendErrorCode(error));
      });
  };

  return {
    state,
    isSupported: getVoiceRecorder().ok,
    text,
    errorCode,
    handlePressStart,
    handlePressEnd,
  };
}

function startErrorCode(error: unknown): SttErrorCode {
  return isDomError(error, "NotAllowedError") ? "MIC_PERMISSION_DENIED" : "MIC_UNAVAILABLE";
}

function sendErrorCode(error: unknown): SttErrorCode {
  if (isDomError(error, "TimeoutError")) return "TIMEOUT";
  if (isDomError(error, "AbortError")) return "ENGINE_UNAVAILABLE";
  return "TRANSCRIPTION_FAILED";
}

function isDomError(error: unknown, name: string): boolean {
  return error instanceof DOMException && error.name === name;
}