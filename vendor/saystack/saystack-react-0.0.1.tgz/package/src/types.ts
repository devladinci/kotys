import type {
  IVoiceRecording,
  SttErrorCode,
} from "@saystack/core";

export type DictationState = "idle" | "recording" | "transcribing" | "done" | "error";

export interface IDictationSendOptions {
  prompt?: string | undefined;
  signal?: AbortSignal | undefined;
}

export interface IUseDictationOptions {
  endpoint?: string | undefined;
  prompt?: string | undefined;
  onText?: ((text: string) => void) | undefined;
}

export interface IUseDictationResult {
  state: DictationState;
  isSupported: boolean;
  text: string;
  errorCode?: SttErrorCode | undefined;
  handlePressStart: () => void;
  handlePressEnd: () => void;
}