export { dictationEndpoint, sendDictation } from "./dictationSender.js";
export { useDictation } from "./useDictation.js";
export type { ISpeechApi, ISpeechHookResult } from "./useSpeech.js";
export { createSpeechApi, useSpeech } from "./useSpeech.js";
export type {
  DictationState,
  IDictationSendOptions,
  IUseDictationOptions,
  IUseDictationResult,
  TranscribeFn,
} from "./types.js";
export type {
  IDictationInput,
  ILiveTranscription,
  LiveTranscriptionFactory,
  INativeRecording,
  IPlatformRecorder,
  IVoiceRecording,
  IVoiceRecorderResult,
  IWebRecording,
} from "@saystack/core";
export { setVoiceRecorder, getVoiceRecorder } from "@saystack/core";
export type {
  ISpeechChunk,
  ISpeechClip,
  ISpeechClipResult,
  ISpeechPosition,
  ISpeechSessionOptions,
  ISpeechState,
  ITtsDriver,
  TtsErrorCode,
  TtsPhase,
} from "@saystack/core";