import type {
  ISttTranscribeResult,
  IVoiceRecording,
} from "@saystack/core";
import { isSttErrorCode } from "@saystack/core";
import type { IDictationSendOptions } from "./types.js";

export function dictationEndpoint(baseUrl: string): string {
  return `${baseUrl.replace(/\/+$/, "")}/v1/audio/transcriptions`;
}

export async function sendDictation(
  endpoint: string,
  recording: IVoiceRecording,
  options: IDictationSendOptions,
): Promise<ISttTranscribeResult> {
  if (!("blob" in recording)) {
    return {
      ok: false,
      errorCode: "RECORDING_UNSUPPORTED",
      message: "web dictation sends a Blob recording; native ones need an app-provided sender",
    };
  }

  const form = new FormData();
  form.append("file", recording.blob, "recording");
  if (options.prompt !== undefined) form.append("prompt", options.prompt);

  const init: RequestInit = { method: "POST", body: form };
  if (options.signal !== undefined) init.signal = options.signal;

  let response: Response;
  try {
    response = await fetch(endpoint, init);
  } catch (error: unknown) {
    const timedOut = error instanceof DOMException && error.name === "TimeoutError";
    return {
      ok: false,
      errorCode: timedOut ? "TIMEOUT" : "ENGINE_UNAVAILABLE",
      message: timedOut ? "transcription timed out" : "could not reach the dictation endpoint",
    };
  }

  return readResponse(response);
}

async function readResponse(response: Response): Promise<ISttTranscribeResult> {
  const parsed = (await response.json().catch(() => undefined)) as {
    text?: string;
    language?: string;
    durationSeconds?: number;
    errorCode?: string;
    message?: string;
  } | undefined;

  if (response.ok && parsed?.text !== undefined) {
    const okResult: ISttTranscribeResult = { ok: true, text: parsed.text };
    if (parsed.language !== undefined) {
      return { ok: true, text: parsed.text, language: parsed.language };
    }
    if (parsed.durationSeconds !== undefined) {
      return { ok: true, text: parsed.text, durationSeconds: parsed.durationSeconds };
    }
    return okResult;
  }

  if (!isSttErrorCode(parsed?.errorCode)) {
    return {
      ok: false,
      errorCode: "TRANSCRIPTION_FAILED",
      message: `dictation endpoint said ${response.status}`,
    };
  }

  const code = parsed.errorCode;
  const failResult: ISttTranscribeResult = { ok: false, errorCode: code };
  if (parsed.message !== undefined) {
    return { ok: false, errorCode: code, message: parsed.message };
  }
  return failResult;
}