import { useContext } from "react";

import { ReadAloudContext } from "./readAloudContext.js";
import type { IReadAloudStore } from "./readAloudStore.js";

export function useReadAloudStore(): IReadAloudStore {
  const store = useContext(ReadAloudContext);

  if (store === null) {
    throw new Error("saystack: read-aloud hooks need a <ReadAloudProvider> above them");
  }

  return store;
}
