import { createContext } from "react";

import type { IReadAloudStore } from "./readAloudStore.js";

export const ReadAloudContext = createContext<IReadAloudStore | null>(null);
