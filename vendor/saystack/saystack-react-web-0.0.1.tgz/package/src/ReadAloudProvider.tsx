import type { ITtsDriver, RequestHeaders } from "@saystack/core";
import { createSpeechSession, hasSpeechText, resolveHeaders } from "@saystack/core";
import { createSpeechApi } from "@saystack/react";
import type { IAudioLevels } from "@saystack/web";
import { createWebTtsDriver } from "@saystack/web";
import type { ReactNode } from "react";
import { useEffect, useRef, useState } from "react";

import { ReadAloudContext } from "./readAloudContext.js";
import type { IReadAloudStore, ReadAloudId } from "./readAloudStore.js";
import { createReadAloudStore } from "./readAloudStore.js";
import { useAudioLevels } from "./useAudioLevels.js";

export type RewriteFn = (markdown: string, signal: AbortSignal) => Promise<string | null>;

export type SummarizeFn = (id: ReadAloudId, markdown: string, signal: AbortSignal) => Promise<string | null>;

interface ISpeechSource {
  endpoint?: string;
  headers?: RequestHeaders;
  driver?: ITtsDriver;
}

interface IProps extends ISpeechSource {
  bands?: number;
  rewrite?: RewriteFn;
  shouldRewrite?: (markdown: string) => boolean;
  summarize?: SummarizeFn;
  children: ReactNode;
}

interface ILatest {
  headers?: RequestHeaders;
  rewrite?: RewriteFn;
  shouldRewrite?: (markdown: string) => boolean;
  summarize?: SummarizeFn;
}

const driverFor = (
  { endpoint, driver }: ISpeechSource,
  headers: () => Readonly<Record<string, string>>,
  output: () => AudioNode | null,
): ITtsDriver => {
  if (driver !== undefined) {
    return driver;
  }

  if (endpoint === undefined) {
    throw new Error("saystack: <ReadAloudProvider> needs an endpoint or a driver");
  }

  return createWebTtsDriver({ endpoint, headers, output });
};

export function ReadAloudProvider({ endpoint, headers, driver, bands, rewrite, shouldRewrite, summarize, children }: IProps) {
  const levels = useAudioLevels(bands === undefined ? { isAudible: true } : { isAudible: true, bands });
  const levelsRef = useRef<IAudioLevels | null>(null);
  const latestRef = useRef<ILatest>({});

  useEffect(() => {
    levelsRef.current = levels;
  }, [levels]);

  useEffect(() => {
    latestRef.current = {
      ...(headers === undefined ? {} : { headers }),
      ...(rewrite === undefined ? {} : { rewrite }),
      ...(shouldRewrite === undefined ? {} : { shouldRewrite }),
      ...(summarize === undefined ? {} : { summarize }),
    };
  });

  const [store] = useState((): IReadAloudStore => {
    const ttsDriver = driverFor(
      { ...(endpoint === undefined ? {} : { endpoint }), ...(driver === undefined ? {} : { driver }) },
      () => resolveHeaders(latestRef.current.headers),
      () => levelsRef.current?.input ?? null,
    );

    const spoken: RewriteFn = async (markdown, signal) => {
      const latest = latestRef.current;
      const id = created.speakingId();

      if (latest.summarize !== undefined && id !== null) {
        const summary = await latest.summarize(id, markdown, signal);
        const isSummary = summary !== null && hasSpeechText(summary);
        created.markSummary(id, isSummary);

        if (isSummary) {
          return summary;
        }
      }

      return latest.rewrite === undefined ? null : latest.rewrite(markdown, signal);
    };

    const session = createSpeechSession(ttsDriver, {
      get rewrite() {
        const latest = latestRef.current;

        return latest.rewrite === undefined && latest.summarize === undefined ? undefined : spoken;
      },
      get shouldRewrite() {
        return latestRef.current.shouldRewrite;
      },
    });
    const created = createReadAloudStore(session, createSpeechApi(session, ttsDriver), () => levelsRef.current?.read());

    return created;
  });

  useEffect(() => store.connect(), [store]);

  return <ReadAloudContext.Provider value={store}>{children}</ReadAloudContext.Provider>;
}
