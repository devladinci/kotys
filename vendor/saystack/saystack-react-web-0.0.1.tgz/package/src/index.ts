export type { AuraAnchor, IUseAuraOptions } from "./useAura.js";
export { useAura } from "./useAura.js";

export { useAudioLevels } from "./useAudioLevels.js";

export { useRecorderLevels } from "./useRecorderLevels.js";

export type { IUseReadAlongOptions } from "./useReadAlong.js";
export { useReadAlong } from "./useReadAlong.js";

export { useSpeechProgress } from "./useSpeechProgress.js";

export type { IUseStreamingInputOptions } from "./useStreamingInput.js";
export { useStreamingInput } from "./useStreamingInput.js";

export type { IUseWebSpeechOptions, IWebSpeech } from "./useWebSpeech.js";
export { useWebSpeech } from "./useWebSpeech.js";

export type { IWordReveal } from "./useWordReveal.js";
export { useWordReveal } from "./useWordReveal.js";

export { SpectrumLine } from "./SpectrumLine.js";

export { default as SpeechPlayer } from "./SpeechPlayer/index.js";
export type { IPlayerLabels } from "./SpeechPlayer/labels.js";
export { DEFAULT_PLAYER_LABELS } from "./SpeechPlayer/labels.js";
