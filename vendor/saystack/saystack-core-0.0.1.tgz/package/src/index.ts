export const VERSION = "0.0.1";

export type {
  ChunkingMode,
  ILlmEngineConfig,
  IConfig,
  IInterruptConfig,
  IReferenceConfig,
  ISttEngineConfig,
  ITtsEngineConfig,
  UnheardPolicy,
} from "./config.js";

export type { IDictationInput, ILiveTranscription, LiveTranscriptionFactory } from "./dictation.js";

export type { RequestHeaders } from "./http.js";
export { resolveHeaders } from "./http.js";

export type { INormalizeFn, INormalizeResult, NormalizeErrorCode } from "./normalize.js";

export type {
  INativeRecording,
  IPlatformRecorder,
  IVoiceRecording,
  IVoiceRecorderResult,
  IWebRecording,
} from "./platform.js";
export { getVoiceRecorder, setVoiceRecorder } from "./platform.js";

export type {
  ISttAdapter,
  ISttCapabilities,
  ISttRealtimeAdapter,
  ISttRealtimeInput,
  ISttRealtimeResult,
  ISttRealtimeSession,
  ISttTranscribeInput,
  ISttTranscribeResult,
  SttErrorCode,
} from "./stt.js";
export { isSttErrorCode } from "./stt.js";

export type { ConfigErrorCode, IConfigError, IValidationResult } from "./validate.js";
export { validateConfig } from "./validate.js";

export type {
  ISpeechChunk,
  ISpeechClip,
  ISpeechClipResult,
  ISpeechPosition,
  ISpeechState,
  ITtsAdapter,
  ITtsCapabilities,
  ITtsDriver,
  ITtsSynthesizeInput,
  ITtsSynthesizeResult,
  TtsErrorCode,
  TtsPhase,
} from "./tts/types.js";

export type { ISpeechOutcome, ISpeechOptions, ISpeechSession, ISpeechSessionOptions } from "./tts/session.js";
export { createSpeechSession } from "./tts/session.js";

export { hasSpeechText, needsSummary, speechChunks, toSpeechText } from "./tts/text.js";

export type { ISpeechEnvelope, ISpeechMark, ISpeechPause, IWordTiming, IWordToken } from "./tts/timing.js";
export { estimateWordTimings, speechEnvelope, tokenizeWords, wordAt, wordTimingsFromMarks } from "./tts/timing.js";

export { alignWords, wordKey } from "./tts/align.js";

export type {
  AuraBackground,
  AuraLayout,
  AuraNumericKey,
  AuraOutline,
  AuraPaletteName,
  AuraPlacement,
  IAuraRange,
  IAuraStyle,
  IAuraStyleOptions,
} from "./aura/style.js";
export {
  AURA_LAYOUTS,
  AURA_OUTLINES,
  AURA_PALETTES,
  AURA_PLACEMENTS,
  AURA_RANGES,
  auraStyleFor,
  DEFAULT_AURA_STYLE,
  MESSAGE_AURA_STYLE,
  resolveAuraStyle,
} from "./aura/style.js";

export type { IBandPalette, LinearRgb } from "./aura/palette.js";
export { bandPalette } from "./aura/palette.js";

export type { IBandMeter, IBandMeterOptions } from "./aura/bandMeter.js";
export { bandEdges, createBandMeter } from "./aura/bandMeter.js";